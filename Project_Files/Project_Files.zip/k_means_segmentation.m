clc;
clear all;
close all;
testimg = imread('Brain1.jpg');
L = imsegkmeans(testimg,5);
mask1 = L==4;
cluster1 = testimg .* uint8(mask1);
figure;
imshow(cluster1);
figure (2);
B = labeloverlay(testimg,L);
imshow(B)
testbw = im2bw(rgb2gray(cluster1));
label = bwlabel(testbw);
stats = regionprops(label, 'Solidity', 'Area');
density = [stats.Solidity];
area = [stats.Area];
high_dense_area = density > 0.5;
max_area = max(area(high_dense_area));
tumour_label = find(area == max_area);
tumour = ismember(label, tumour_label);

test2 = im2bw(testimg, 0.7);
label2 = (bwlabel(test2))/2;
stats2 = regionprops(label, 'Solidity', 'Area');
density2 = [stats2.Solidity];
area2 = [stats2.Area];
high_dense_area2 = density2 > 0.5;
max_area2 = max(area2(high_dense_area2));
tumour_label2 = find(area2 == max_area2);
tumour2 = ismember(label2, tumour_label2);

figure(3);
imshow(tumour);
figure(4);
imshow(tumour2);

similarity = jaccard(tumour, tumour2);
figure(5);
imshowpair(tumour, tumour2);
title(['Jaccard Index = ' num2str(similarity)]);